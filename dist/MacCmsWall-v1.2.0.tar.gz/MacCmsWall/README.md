# MacCmsWall

MacCmsWall 是一个基于 Linux `chattr +i` 的网站防篡改插件，面向 BT / aaPanel 第三方插件部署场景。

## 核心目标

当前版本只解决一件事：网站文件不可篡改。

- 默认启用强防护（`chattr +i`）
- 支持严格全锁模式
- 支持 MACCMS 兼容模式
- 支持 Web UI 管理后台
- 支持 GitHub 一键安装

## 防护模式

1. 严格全锁模式
- 对站点扫描到的全部文件执行 `chattr +i`

2. MACCMS 兼容模式
- 自动跳过以下目录：
- `/runtime/`
- `/cache/`
- `/static/upload/`
- `/upload/`
- 其余文件执行 `chattr +i`

## 项目结构

```text
MacCmsWall
├── onekey.sh
├── install.sh
├── uninstall.sh
├── README.md
├── panel/
│   ├── info.json
│   ├── index.html
│   ├── main.py
│   ├── static/
│   │   ├── style.css
│   │   └── app.js
│   ├── templates/
│   └── data/
├── scripts/
│   ├── common.sh
│   ├── lock.sh
│   ├── unlock.sh
│   ├── scan.sh
│   └── restore.sh
├── database/
│   └── init.sql
└── logs/
```

## 安装

```bash
curl -fsSL https://raw.githubusercontent.com/safemac/MacCmsWall/main/onekey.sh | bash
```

## 一键傻瓜智能模式（推荐）

默认就是一行命令自动处理：

- 未安装时自动安装
- 已安装时自动更新
- 自动识别 BT / aaPanel

如需指定动作，可在同一行增加环境变量：

```bash
MACCMSWALL_ACTION=install curl -fsSL https://raw.githubusercontent.com/safemac/MacCmsWall/main/onekey.sh | bash
MACCMSWALL_ACTION=update curl -fsSL https://raw.githubusercontent.com/safemac/MacCmsWall/main/onekey.sh | bash
MACCMSWALL_ACTION=uninstall curl -fsSL https://raw.githubusercontent.com/safemac/MacCmsWall/main/onekey.sh | bash
```

支持自定义分支与仓库：

```bash
MACCMSWALL_REPO=https://github.com/safemac/MacCmsWall.git MACCMSWALL_BRANCH=main curl -fsSL https://raw.githubusercontent.com/safemac/MacCmsWall/main/onekey.sh | bash
```

脚本能力：

- 自动识别 BT / aaPanel
- 自动安装依赖（git/curl/sqlite3/python3/e2fsprogs）
- 自动拉取并部署插件
- 自动初始化数据库
- 更新时自动恢复历史数据库与日志
- 自动尝试重启面板

## 更新

```bash
bash /www/server/panel/plugin/MacCmsWall/update.sh
```

更新行为：

- 从 GitHub 拉取最新代码
- 复用 install.sh 执行安全升级
- 自动保留数据库与日志
- 自动尝试重启面板

## 卸载

```bash
bash /www/server/panel/plugin/MacCmsWall/uninstall.sh
```

卸载行为：

- 自动尝试解锁已保护站点
- 备份数据库与日志到 `/tmp/MacCmsWall_backup_时间戳`
- 删除插件目录
- 自动尝试重启面板

## API 概览（panel/main.py）

- `health`
- `get_modes`
- `get_dashboard`
- `list_sites`
- `add_site`
- `update_mode`
- `enable_protection`
- `disable_protection`
- `rescan_site`
- `relock_site`
- `remove_site`
- `get_logs`
- `clear_logs`

## 开发说明

- 后端：Python3 + SQLite
- 前端：HTML + CSS + JavaScript
- 防护：Shell 调用 `chattr`
- 默认目录：`/www/server/panel/plugin/MacCmsWall`

## 分发构建

```bash
bash scripts/build_release.sh
```

构建产物位于 `dist/`：

- `MacCmsWall-vX.Y.Z.tar.gz`
- `MacCmsWall-vX.Y.Z.zip`（系统存在 zip 命令时）
- `MacCmsWall-vX.Y.Z.sha256`（系统存在 sha256sum 时）

> 注意：`chattr +i` 依赖底层文件系统支持（常见 ext4/xfs 等环境请先验证）。
